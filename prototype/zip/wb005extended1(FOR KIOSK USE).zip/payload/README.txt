--------------------------------
WEBBREW INSTALL INSTRUCTIONS:
--------------------------------

1. create payload folder
2. put index.html in the same directory as payload folder
3. put BOOT.html inside payloads folder
4. create apps folder inside payloads
5. put the contents of appdist.zip into apps folder
6. open index.html and bookmark it
7. done

your directory structure should look like this:

-index.html
|
-payloads-
         |
         -BOOT.html
         |
         -apps-
              |
              -all of your apps here