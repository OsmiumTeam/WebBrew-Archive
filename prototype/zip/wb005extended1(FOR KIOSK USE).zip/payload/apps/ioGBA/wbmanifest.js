var ioGBA = {

exist:1,
title:"Iodine GBA",
description:"GameBoy Advance Emulator in your Browser!",
width:480,
height:365,
favicon:"about:blank",
icon:"about:blank",
index:"index.html"

};