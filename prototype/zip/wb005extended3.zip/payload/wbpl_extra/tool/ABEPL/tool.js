
addTool("ABE Payload Loader").addEventListener("click", function() {
    
    popup.open("payload/wbpl_extra/tool/ABEPL/index.html" ,480, 360, "ABE Payload Loader v1.0", 
"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAoklEQVQ4jWNkgID/DOQBRkYGBob/BoFNcJGidYVw9v4rHxgYGBgYHux/wMDAwMCwaL8tim7Z9QwMLAwMDAyGTYlkOoCBgZGBgeG/46TDcIHEXAOiNccx8kIMINt6BqgX/v8nzwxGRkaIATAOMkA2lJGREaclLMgcYjUhAyYiXUs7A1C8gBwOxAYszjAgFlDXC/gArmhmQRfABvDJwYwlOzsDAOPpMTE9Ko8lAAAAAElFTkSuQmCC")
})
popup.open("payload/wbpl_extra/tool/ABEPL/index.html" ,480, 360, "ABE Payload Loader v1.0", 
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAoklEQVQ4jWNkgID/DOQBRkYGBob/BoFNcJGidYVw9v4rHxgYGBgYHux/wMDAwMCwaL8tim7Z9QwMLAwMDAyGTYlkOoCBgZGBgeG/46TDcIHEXAOiNccx8kIMINt6BqgX/v8nzwxGRkaIATAOMkA2lJGREaclLMgcYjUhAyYiXUs7A1C8gBwOxAYszjAgFlDXC/gArmhmQRfABvDJwYwlOzsDAOPpMTE9Ko8lAAAAAElFTkSuQmCC")